static int __foo;

